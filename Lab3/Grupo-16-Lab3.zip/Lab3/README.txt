Integrantes Grupo 16:
    José Castro, 202073550-6
    Florencia Ramírez, 202073522-0

☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆

Instrucciones de compilación:
    Esta tarea fue hecha con go 1.22.2.
    Se deben abrir 2 terminales distintas en la dirección de la carpeta Lab3.
    En la primera terminal se ejecutará el código en Docker de la tierra.
        $ make docker
    Una vez que se ejecuta el contenedor, en la segunda terminal se ejecuta el código de los equipos.
        $ make equipo

☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆

Comentarios extra:
    - Se asume que el código de los equipos se ejecutará luego de la creación y ejecución del contenedor.
    - La ejecución del contenedor no termina cuando finaliza la ejecución de los equipos, se debe presionar Ctrl + C para finalizarla.
    - Para mantener la consistencia se guardó todo en la carpeta Lab3.